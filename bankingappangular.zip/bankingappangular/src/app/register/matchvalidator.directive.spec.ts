import { MatchValidatorDirective } from './matchvalidator.directive';

describe('MatchvalidatorDirective', () => {
  it('should create an instance', () => {
    //const directive = new MatchValidatorDirective();
    //expect(directive).toBeTruthy();
  });
});
