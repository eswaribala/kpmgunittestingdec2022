import { PhotoPipe } from './photo.pipe';

describe('PhotoPipe', () => {
  it('create an instance', () => {
    const pipe = new PhotoPipe();
    expect(pipe).toBeTruthy();
  });
});
