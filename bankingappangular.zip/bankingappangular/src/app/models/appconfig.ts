export const logo='../assets/images/logo.jpg'
export const title='Global Bank'
export const banner='../assets/images/banner.png'
