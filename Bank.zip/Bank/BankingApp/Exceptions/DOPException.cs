﻿namespace BankingApp.Exceptions
{
    public class DOPException:ApplicationException
    {

        public DOPException(string message):base(message)
        {
            
        }
    }
}
