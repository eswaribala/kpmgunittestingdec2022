﻿namespace BankingApp.Models
{
    public class Corporate:Customer
    {
    }
}
