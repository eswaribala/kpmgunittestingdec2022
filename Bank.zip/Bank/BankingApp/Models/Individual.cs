﻿namespace BankingApp.Models
{
    public class Individual:Customer
    {
    }
}
